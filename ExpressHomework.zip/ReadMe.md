# Express Assignment
## Important
* I used "type": "module" in my package.json file, so you will need it as well.
    - Instead of const express = require('express'), I can use the line "import express from 'express' ", so you MUST have the "type": "module" line in your package.json file, or just use my package.json file.
    - Make sure to run "npm install" to get my dependencies from the package.json file if you use mine.



